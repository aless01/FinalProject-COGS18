from functions import *

def question_test1():
    assert functions.question()==True

def question_test2():
    assert newquestion()==True
    
def question_test3():
    assert project()==True
    
def question_test4():
    assert selfcare()==True
    
def question_test5():
    assert feedback()==True
    
def question_test6():
    assert improvement()==True
    
def question_test7():
    assert again()==True
    